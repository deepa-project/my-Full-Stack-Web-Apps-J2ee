/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author Administrator
 */
public class faculty {

    String facultyLogin,facultyName,facultyAddress,facultyCourse,facultyEmail;

    public String getFacultyEmail() {
        return facultyEmail;
    }

    public void setFacultyEmail(String facultyEmail) {
        this.facultyEmail = facultyEmail;
    }

    public String getFacultyAddress() {
        return facultyAddress;
    }

    public void setFacultyAddress(String facultyAddress) {
        this.facultyAddress = facultyAddress;
    }

    public String getFacultyCourse() {
        return facultyCourse;
    }

    public void setFacultyCourse(String facultyCourse) {
        this.facultyCourse = facultyCourse;
    }

    public String getFacultyLogin() {
        return facultyLogin;
    }

    public void setFacultyLogin(String facultyLogin) {
        this.facultyLogin = facultyLogin;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }
    

}
