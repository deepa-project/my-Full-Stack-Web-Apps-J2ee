/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package model;

/**
 *
 * @author Administrator
 */
public class studycenter {

    int studycenter_id;

    public int getStudycenter_id() {
        return studycenter_id;
    }

    public void setStudycenter_id(int studycenter_id) {
        this.studycenter_id = studycenter_id;
    }
     String studycenter_name,studycenter_location;

  

    public String getStudycenter_location() {
        return studycenter_location;
    }

    public void setStudycenter_location(String studycenter_location) {
        this.studycenter_location = studycenter_location;
    }

    public String getStudycenter_name() {
        return studycenter_name;
    }

    public void setStudycenter_name(String studycenter_name) {
        this.studycenter_name = studycenter_name;
    }
    

}
