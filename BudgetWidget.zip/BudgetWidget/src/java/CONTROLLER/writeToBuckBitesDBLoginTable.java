/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CONTROLLER;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author shanki_1974
 */
public class writeToBuckBitesDBLoginTable extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /*
             * TODO output your page here. You may use following sample code.
             */
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet writeToBuckBitesDBLoginTable</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet writeToBuckBitesDBLoginTable at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {            
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
       
        String loginName=request.getParameter("loginName").toString();
        String pwd=request.getParameter("Pwd").toString();
        String address=request.getParameter("address").toString();
        if(address.equals(""))
            address.concat("NO ADDRESS ENTERED");
         String city=request.getParameter("city").toString();
         if(city.equals(""))city.concat("CITY UNNAMED");
        String phone=request.getParameter("phone").toString();      
        if(phone.equals(""))phone.concat("0000000000");
        String email=request.getParameter("email").toString();
        if(email.equals("")) email.concat("no-email@no-email.com");
        
        
        
        try{
        Class.forName("org.apache.derby.jdbc.ClientDriver");
    Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/BuckBitesDB","deepa","password");
    PreparedStatement ps=con.prepareStatement("insert into Deepa.Login(loginname,loginpwd,addr,city,email,phone)values(?,?,?,?,?,?)");
    ps.setString(1, loginName);
    ps.setString(2, pwd);
    ps.setString(3, address);
    ps.setString(4, city);
    ps.setString(6, phone);
    ps.setString(5,email);
    ps.executeUpdate();
    
        response.sendRedirect("login.jsp");
          
           
   
      ps.close();
    con.close();
        }
        catch(Exception e){
        e.printStackTrace();
response.sendRedirect("createLogin.jsp");
        }
        finally{
      
        
      
        
        
        
        
        
        }
        
        
        
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
